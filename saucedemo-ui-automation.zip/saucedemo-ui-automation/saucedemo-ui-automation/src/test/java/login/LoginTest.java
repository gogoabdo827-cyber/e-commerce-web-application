package login;

import base.BaseTest;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.LoginPage;

import java.time.Duration;

/**
 * Test class covering login functionality on SauceDemo.
 * TC001: Successful login
 * TC002: Invalid username variations
 * TC003: Invalid password variations
 */
public class LoginTest extends BaseTest {

    private static final String VALID_USERNAME = "standard_user";
    private static final String VALID_PASSWORD = "secret_sauce";
    private static final String EXPECTED_ERROR_MESSAGE =
            "Epic sadface: Username and password do not match any user in this service";

    /**
     * TC001 - Successful Login
     * Verifies that a valid username/password combination logs the user
     * in and redirects to the inventory page.
     */
    @Test( priority = 1 , description = "TC001 - Verify successful login with valid credentials")
    public void testSuccessfulLogin() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(VALID_USERNAME, VALID_PASSWORD);

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlContains("inventory.html"));

        Assert.assertTrue(
                driver.getCurrentUrl().contains("inventory.html"),
                "Expected URL to contain 'inventory.html' after successful login"
        );
    }

    /**
     * TC002 - Invalid Username
     * Verifies that logging in with an invalid username (paired with the
     * valid password) always produces the standard error message.
     */
    @Test(priority = 2,dataProvider = "invalidUsernames", description = "TC002 - Verify error message for invalid usernames")
    public void testInvalidUsername(String invalidUsername) {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(invalidUsername, VALID_PASSWORD);

        String actualError = loginPage.getErrorMessage();
        Assert.assertEquals(
                actualError,
                EXPECTED_ERROR_MESSAGE,
                "Error message did not match for invalid username: " + invalidUsername
        );
    }

    /**
     * TC003 - Invalid Password
     * Verifies that logging in with the valid username but an invalid
     * password always produces the standard error message.
     */
    @Test(priority = 3 ,dataProvider = "invalidPasswords", description = "TC003 - Verify error message for invalid passwords")
    public void testInvalidPassword(String invalidPassword) {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(VALID_USERNAME, invalidPassword);

        String actualError = loginPage.getErrorMessage();
        Assert.assertEquals(
                actualError,
                EXPECTED_ERROR_MESSAGE,
                "Error message did not match for invalid password: " + invalidPassword
        );
    }

    /**
     * Data provider supplying a variety of invalid usernames:
     * English letters, Arabic letters, numbers, and special characters.
     */
    @DataProvider(name = "invalidUsernames")
    public Object[][] invalidUsernames() {
        return new Object[][]{
                {"wrong_user"},          // English letters
                {"مستخدم_خاطئ"},          // Arabic letters
                {"123456"},               // Numbers
                {"!@#$%^&*()"},           // Special characters
                {"standard_user "}        // Valid username with trailing space (edge case)
        };
    }

    /**
     * Data provider supplying a variety of invalid passwords:
     * English letters, Arabic letters, numbers, and special characters.
     */
    @DataProvider(name = "invalidPasswords")
    public Object[][] invalidPasswords() {
        return new Object[][]{
                {"wrongpass"},            // English letters
                {"كلمة_مرور_خاطئة"},       // Arabic letters
                {"000000"},               // Numbers
                {"!@#$%^&*()"},           // Special characters
                {"secret_sauce "}         // Valid password with trailing space (edge case)
        };
    }
}