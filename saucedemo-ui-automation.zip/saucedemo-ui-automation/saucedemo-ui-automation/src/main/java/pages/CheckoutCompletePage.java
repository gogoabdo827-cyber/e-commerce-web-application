package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * Page Object representing the Checkout Complete (order confirmation) page.
 */
public class CheckoutCompletePage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By completeHeader = By.className("complete-header");
    private final By backHomeButton = By.id("back-to-products");

    public CheckoutCompletePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public String getConfirmationHeader() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(completeHeader)).getText();
    }

    public boolean isOrderCompleteDisplayed() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(completeHeader)).isDisplayed();
    }

    public ProductsPage clickBackHome() {
        WebElement backBtn = wait.until(ExpectedConditions.elementToBeClickable(backHomeButton));
        backBtn.click();
        return new ProductsPage(driver);
    }
}