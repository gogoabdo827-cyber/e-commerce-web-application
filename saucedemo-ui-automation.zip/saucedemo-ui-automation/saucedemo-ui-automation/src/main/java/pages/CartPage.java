package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Page Object representing the SauceDemo Cart page.
 */
public class CartPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By cartList = By.className("cart_list");
    private final By cartItems = By.className("cart_item");
    private final By cartItemNames = By.className("inventory_item_name");
    private final By checkoutButton = By.id("checkout");
    private final By continueShoppingButton = By.id("continue-shopping");

    public CartPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public boolean isDisplayed() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(cartList)).isDisplayed();
    }

    public List<String> getCartItemNames() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cartList));
        return driver.findElements(cartItemNames)
                .stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    public int getCartItemCount() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cartList));
        return driver.findElements(cartItems).size();
    }

    public void removeItem(String productName) {
        List<WebElement> items = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(cartItems));
        items.stream()
                .filter(item -> item.findElement(cartItemNames).getText().equals(productName))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Product not found in cart: " + productName))
                .findElement(By.cssSelector("button.cart_button"))
                .click();
    }

    public CheckoutStepOnePage clickCheckout() {
        wait.until(ExpectedConditions.elementToBeClickable(checkoutButton)).click();
        return new CheckoutStepOnePage(driver);
    }

    public ProductsPage clickContinueShopping() {
        wait.until(ExpectedConditions.elementToBeClickable(continueShoppingButton)).click();
        return new ProductsPage(driver);
    }
}
