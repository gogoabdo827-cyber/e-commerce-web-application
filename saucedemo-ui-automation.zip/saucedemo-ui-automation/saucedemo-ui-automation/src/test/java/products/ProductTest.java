package products;

import base.BaseTest;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.LoginPage;
import pages.ProductDetailsPage;
import pages.ProductsPage;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Test class covering product / inventory functionality on SauceDemo.
 * TC004: Product details verification
 * TC005: About page navigation
 * TC006: All Items navigation
 * TC007: Logout
 * TC008: Reset App State
 * TC009: Sorting (Name A-Z, Name Z-A, Price Low-High, Price High-Low)
 * TC010: Add a single item to the cart
 * TC011: Add multiple items to the cart
 */
public class ProductTest extends BaseTest {

    private static final String VALID_USERNAME = "standard_user";
    private static final String VALID_PASSWORD = "secret_sauce";

    /**
     * Logs in with valid credentials and returns the resulting ProductsPage.
     * Shared by every test in this class to avoid duplicating the login flow.
     */
    private ProductsPage loginAsStandardUser() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(VALID_USERNAME, VALID_PASSWORD);
        return new ProductsPage(driver);
    }

    /**
     * TC004 - Verify Product Details
     * Iterates through every product on the Inventory page, opens its
     * details screen, verifies all expected elements, then returns to
     * the Inventory page for the next product.
     */
    @Test(priority = 4, description = "TC004 - Verify product details for every product on the Inventory page")
    public void testProductDetails() {
        ProductsPage productsPage = loginAsStandardUser();
        List<String> productNames = productsPage.getDisplayedProductNames();

        Assert.assertFalse(productNames.isEmpty(), "No products found on the Inventory page");

        for (String productName : productNames) {
            ProductDetailsPage detailsPage = productsPage.clickProduct(productName);

            Assert.assertEquals(
                    detailsPage.getProductName(),
                    productName,
                    "Product name on details page did not match the inventory listing"
            );
            Assert.assertFalse(
                    detailsPage.getProductDescription().isEmpty(),
                    "Product description was empty for: " + productName
            );
            Assert.assertTrue(
                    detailsPage.getProductPrice().startsWith("$"),
                    "Product price was not displayed correctly for: " + productName
            );
            Assert.assertTrue(
                    detailsPage.isProductImageDisplayed(),
                    "Product image was not displayed for: " + productName
            );
            Assert.assertTrue(
                    detailsPage.isAddToCartButtonDisplayed(),
                    "Add to Cart button was not displayed for: " + productName
            );
            Assert.assertTrue(
                    detailsPage.isBackToProductsButtonDisplayed(),
                    "Back to Products button was not displayed for: " + productName
            );

            productsPage = detailsPage.clickBackToProducts();
            Assert.assertTrue(productsPage.isDisplayed(), "Did not return to the Inventory page for: " + productName);
        }
    }

    /**
     * TC005 - Verify About Page
     * Opens the side menu and clicks About, then verifies the About
     * page (an external SauceLabs page) opens successfully.
     */
    @Test(priority = 5, description = "TC005 - Verify the About page opens from the side menu")
    public void testAboutPage() {
        ProductsPage productsPage = loginAsStandardUser();
        productsPage.menu().openMenu();
        productsPage.menu().clickAbout();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlContains("saucelabs.com"));

        Assert.assertTrue(
                driver.getCurrentUrl().contains("saucelabs.com"),
                "Expected to navigate to the SauceLabs About page"
        );
    }

    /**
     * TC006 - Verify All Items
     * From the Cart page, opens the side menu and clicks All Items,
     * verifying the user is returned to the Inventory page.
     */
    @Test(priority = 6, description = "TC006 - Verify All Items navigates back to the Inventory page")
    public void testAllItemsNavigation() {
        ProductsPage productsPage = loginAsStandardUser();
        CartPage cartPage = productsPage.openCart();
        Assert.assertTrue(cartPage.isDisplayed(), "Cart page was not displayed");

        productsPage = new ProductsPage(driver);
        productsPage.menu().openMenu();
        productsPage.menu().clickAllItems();

        Assert.assertTrue(productsPage.isDisplayed(), "Inventory page was not displayed after clicking All Items");
    }

    /**
     * TC007 - Verify Logout
     * Opens the side menu and clicks Logout, verifying the Login page
     * is displayed afterwards.
     */
    @Test(priority = 7, description = "TC007 - Verify logout returns the user to the Login page")
    public void testLogout() {
        ProductsPage productsPage = loginAsStandardUser();
        productsPage.menu().openMenu();
        productsPage.menu().clickLogout();

        LoginPage loginPage = new LoginPage(driver);
        Assert.assertTrue(loginPage.isLoginPageDisplayed(), "Login page was not displayed after logout");
    }

    /**
     * TC008 - Verify Reset App State
     * Adds a product to the cart, then resets the app state and
     * verifies the cart badge is removed and the product button
     * reverts to its original "Add to cart" label.
     */
    @Test(priority = 8, description = "TC008 - Verify Reset App State clears the cart")
    public void testResetAppState() {
        ProductsPage productsPage = loginAsStandardUser();
        String productName = productsPage.getDisplayedProductNames().get(0);

        productsPage.addToCart(productName);
        Assert.assertEquals(productsPage.getCartBadgeCount(), 1, "Cart badge did not show 1 item after adding a product");

        productsPage.menu().openMenu();
        productsPage.menu().clickResetAppState();

        Assert.assertEquals(productsPage.getCartBadgeCount(), 0, "Cart badge was not removed after Reset App State");
        Assert.assertTrue(
                productsPage.getCartButtonLabel(productName).equalsIgnoreCase("Add to cart"),
                "Product button did not revert to 'Add to cart' after Reset App State"
        );
    }

    /**
     * TC009 - Verify Sorting: Name A -> Z
     */
    @Test(priority = 9, description = "TC009 - Verify sorting products by Name A to Z")
    public void testSortByNameAToZ() {
        ProductsPage productsPage = loginAsStandardUser();
        productsPage.sortByNameAToZ();

        List<String> actualOrder = productsPage.getDisplayedProductNames();
        List<String> expectedOrder = new ArrayList<>(actualOrder);
        expectedOrder.sort(Comparator.naturalOrder());

        Assert.assertEquals(actualOrder, expectedOrder, "Products were not sorted alphabetically A to Z");
    }

    /**
     * TC009 - Verify Sorting: Name Z -> A
     */
    @Test(priority = 9, description = "TC009 - Verify sorting products by Name Z to A")
    public void testSortByNameZToA() {
        ProductsPage productsPage = loginAsStandardUser();
        productsPage.sortByNameZToA();

        List<String> actualOrder = productsPage.getDisplayedProductNames();
        List<String> expectedOrder = new ArrayList<>(actualOrder);
        expectedOrder.sort(Comparator.reverseOrder());

        Assert.assertEquals(actualOrder, expectedOrder, "Products were not sorted alphabetically Z to A");
    }

    /**
     * TC009 - Verify Sorting: Price Low -> High
     */
    @Test(priority = 9, description = "TC009 - Verify sorting products by Price Low to High")
    public void testSortByPriceLowToHigh() {
        ProductsPage productsPage = loginAsStandardUser();
        productsPage.sortByPriceLowToHigh();

        List<Double> actualOrder = productsPage.getDisplayedProductPrices();
        List<Double> expectedOrder = new ArrayList<>(actualOrder);
        expectedOrder.sort(Comparator.naturalOrder());

        Assert.assertEquals(actualOrder, expectedOrder, "Products were not sorted by price Low to High");
    }

    /**
     * TC009 - Verify Sorting: Price High -> Low
     */
    @Test(priority = 9, description = "TC009 - Verify sorting products by Price High to Low")
    public void testSortByPriceHighToLow() {
        ProductsPage productsPage = loginAsStandardUser();
        productsPage.sortByPriceHighToLow();

        List<Double> actualOrder = productsPage.getDisplayedProductPrices();
        List<Double> expectedOrder = new ArrayList<>(actualOrder);
        expectedOrder.sort(Comparator.reverseOrder());

        Assert.assertEquals(actualOrder, expectedOrder, "Products were not sorted by price High to Low");
    }

    /**
     * TC010 - Verify Add Single Item
     */
    @Test(priority = 10, description = "TC010 - Verify adding a single product to the cart")
    public void testAddSingleItemToCart() {
        ProductsPage productsPage = loginAsStandardUser();
        String productName = productsPage.getDisplayedProductNames().get(0);

        productsPage.addToCart(productName);
        Assert.assertEquals(productsPage.getCartBadgeCount(), 1, "Cart badge did not equal 1 after adding one product");

        CartPage cartPage = productsPage.openCart();
        Assert.assertEquals(cartPage.getCartItemCount(), 1, "Cart did not contain exactly 1 item");
        Assert.assertTrue(
                cartPage.getCartItemNames().contains(productName),
                "Cart did not contain the expected product: " + productName
        );
    }

    /**
     * TC011 - Verify Add Multiple Items
     */
    @Test(priority = 11, description = "TC011 - Verify adding multiple products to the cart")
    public void testAddMultipleItemsToCart() {
        ProductsPage productsPage = loginAsStandardUser();
        List<String> allProductNames = productsPage.getDisplayedProductNames();

        List<String> productsToAdd = allProductNames.size() >= 3
                ? allProductNames.subList(0, 3)
                : allProductNames;

        for (String productName : productsToAdd) {
            productsPage.addToCart(productName);
        }

        Assert.assertEquals(
                productsPage.getCartBadgeCount(),
                productsToAdd.size(),
                "Cart badge did not match the number of added products"
        );

        CartPage cartPage = productsPage.openCart();
        Assert.assertEquals(
                cartPage.getCartItemCount(),
                productsToAdd.size(),
                "Cart item count did not match the number of added products"
        );

        List<String> cartItemNames = cartPage.getCartItemNames();
        for (String productName : productsToAdd) {
            Assert.assertTrue(
                    cartItemNames.contains(productName),
                    "Cart did not contain expected product: " + productName
            );
        }
    }
}