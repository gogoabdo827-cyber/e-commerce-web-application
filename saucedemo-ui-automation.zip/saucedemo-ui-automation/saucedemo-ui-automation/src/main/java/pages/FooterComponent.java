package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * Reusable component representing the SauceDemo footer, specifically
 * the social media links (X/Twitter, Facebook, LinkedIn). The footer
 * is available on Inventory-adjacent pages, so its locators and
 * interactions are centralized here instead of being duplicated
 * inside ProductsPage or any test class.
 */
public class FooterComponent {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By twitterLink = By.cssSelector("[data-test='social-twitter']");
    private final By facebookLink = By.cssSelector("[data-test='social-facebook']");
    private final By linkedinLink = By.cssSelector("[data-test='social-linkedin']");

    public FooterComponent(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    /**
     * Scrolls the footer link into view and clicks the X (Twitter) icon.
     * The link opens in a new browser tab; switching to and verifying
     * that tab is the test's responsibility.
     */
    public void clickTwitter() {
        clickFooterLink(twitterLink);
    }

    /**
     * Scrolls the footer link into view and clicks the Facebook icon.
     */
    public void clickFacebook() {
        clickFooterLink(facebookLink);
    }

    /**
     * Scrolls the footer link into view and clicks the LinkedIn icon.
     */
    public void clickLinkedIn() {
        clickFooterLink(linkedinLink);
    }

    /**
     * Internal helper: waits for the given footer link to be present,
     * scrolls it into view (footer links can sit below the fold), then
     * clicks it once it is clickable.
     */
    private void clickFooterLink(By locator) {
        WebElement link = wait.until(ExpectedConditions.presenceOfElementLocated(locator));
        ((org.openqa.selenium.JavascriptExecutor) driver)
                .executeScript("arguments[0].scrollIntoView({block: 'center'});", link);
        wait.until(ExpectedConditions.elementToBeClickable(locator)).click();
    }
}