package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Page Object representing the SauceDemo Inventory (Products) page.
 * Represents ONLY the inventory listing screen. Product detail elements
 * live in {@link ProductDetailsPage}; menu elements live in
 * {@link MenuComponent}; footer/social links live in {@link FooterComponent}.
 */
public class ProductsPage {

    private final WebDriver driver;
    private final WebDriverWait wait;
    private final MenuComponent menuComponent;
    private final FooterComponent footerComponent;

    private final By inventoryContainer = By.id("inventory_container");
    private final By inventoryItems = By.className("inventory_item");
    private final By inventoryItemNames = By.className("inventory_item_name");
    private final By inventoryItemPrices = By.className("inventory_item_price");
    private final By sortDropdown = By.className("product_sort_container");
    private final By cartLink = By.className("shopping_cart_link");
    private final By cartBadge = By.className("shopping_cart_badge");

    public ProductsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.menuComponent = new MenuComponent(driver);
        this.footerComponent = new FooterComponent(driver);
    }

    /**
     * Exposes the reusable side menu component.
     */
    public MenuComponent menu() {
        return menuComponent;
    }

    /**
     * Exposes the reusable footer component (social media links).
     */
    public FooterComponent footer() {
        return footerComponent;
    }

    public boolean isDisplayed() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(inventoryContainer)).isDisplayed();
    }

    // ---- Internal helper ----

    private WebElement findItemContainer(String productName) {
        List<WebElement> items = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(inventoryItems));
        return items.stream()
                .filter(item -> item.findElement(inventoryItemNames).getText().equals(productName))
                .findFirst()
                .orElseThrow(() -> new NoSuchProductException(productName));
    }

    // ---- Navigation to Product Details ----

    public ProductDetailsPage clickProduct(String productName) {
        WebElement item = findItemContainer(productName);
        item.findElement(inventoryItemNames).click();
        return new ProductDetailsPage(driver);
    }

    public ProductDetailsPage clickProductImage(String productName) {
        WebElement item = findItemContainer(productName);
        item.findElement(By.className("inventory_item_img")).click();
        return new ProductDetailsPage(driver);
    }

    // ---- Cart actions ----

    public void addToCart(String productName) {
        WebElement item = findItemContainer(productName);
        item.findElement(By.cssSelector("button.btn_inventory")).click();
    }

    public void removeFromCart(String productName) {
        WebElement item = findItemContainer(productName);
        item.findElement(By.cssSelector("button.btn_inventory")).click();
    }

    /**
     * Returns the current label of a product's cart button
     * (e.g. "Add to cart" or "Remove"). Useful for verifying
     * state changes such as after Reset App State.
     */
    public String getCartButtonLabel(String productName) {
        WebElement item = findItemContainer(productName);
        return item.findElement(By.cssSelector("button.btn_inventory")).getText();
    }

    public CartPage openCart() {
        wait.until(ExpectedConditions.elementToBeClickable(cartLink)).click();
        return new CartPage(driver);
    }

    public int getCartBadgeCount() {
        List<WebElement> badges = driver.findElements(cartBadge);
        if (badges.isEmpty()) {
            return 0;
        }
        return Integer.parseInt(badges.get(0).getText().trim());
    }

    // ---- Sorting ----

    private void selectSortOption(String optionValue) {
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(sortDropdown));
        new Select(dropdown).selectByValue(optionValue);
    }

    public void sortByNameAToZ() {
        selectSortOption("az");
    }

    public void sortByNameZToA() {
        selectSortOption("za");
    }

    public void sortByPriceLowToHigh() {
        selectSortOption("lohi");
    }

    public void sortByPriceHighToLow() {
        selectSortOption("hilo");
    }

    // ---- Utility ----

    public List<String> getDisplayedProductNames() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(inventoryContainer));
        return driver.findElements(inventoryItemNames)
                .stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    public List<Double> getDisplayedProductPrices() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(inventoryContainer));
        return driver.findElements(inventoryItemPrices)
                .stream()
                .map(priceEl -> Double.parseDouble(priceEl.getText().replace("$", "")))
                .collect(Collectors.toList());
    }

    /**
     * Thrown when a product name cannot be located on the inventory page,
     * giving clearer failure messages than a generic Selenium exception.
     */
    public static class NoSuchProductException extends RuntimeException {
        public NoSuchProductException(String productName) {
            super("Product not found on inventory page: " + productName);
        }
    }
}
