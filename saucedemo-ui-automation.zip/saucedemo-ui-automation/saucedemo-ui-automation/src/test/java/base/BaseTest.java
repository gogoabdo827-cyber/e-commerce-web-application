package base;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

/**
 * Shared browser setup and cleanup for all UI tests.
 */
public class BaseTest {

    protected WebDriver driver;

    private static final String BASE_URL =
            System.getProperty("baseUrl", "https://www.saucedemo.com");

    @BeforeMethod
    public void setUp() {

        FirefoxOptions options = new FirefoxOptions();

        boolean headless = Boolean.parseBoolean(
                System.getProperty("headless", "false"));

        if (headless) {
            options.addArguments("-headless");
        }

        driver = new FirefoxDriver(options);

        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(30));

        // Using explicit waits only.
        driver.manage().timeouts().implicitlyWait(Duration.ZERO);

        if (!headless) {
            driver.manage().window().maximize();
        }

        driver.get(BASE_URL);
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}