package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * Reusable component representing the SauceDemo side (hamburger) menu.
 * The menu is available on every logged-in page, so its locators and
 * interactions are centralized here instead of being duplicated across
 * ProductsPage, CartPage, etc.
 */
public class MenuComponent {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By menuButton = By.id("react-burger-menu-btn");
    private final By closeMenuButton = By.id("react-burger-cross-btn");
    private final By allItemsLink = By.id("inventory_sidebar_link");
    private final By aboutLink = By.id("about_sidebar_link");
    private final By logoutLink = By.id("logout_sidebar_link");
    private final By resetAppStateLink = By.id("reset_sidebar_link");

    public MenuComponent(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    /**
     * Opens the side menu and waits until its links are visible.
     */
    public void openMenu() {
        WebElement menuBtn = wait.until(ExpectedConditions.elementToBeClickable(menuButton));
        menuBtn.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(allItemsLink));
    }

    /**
     * Closes the side menu.
     */
    public void closeMenu() {
        WebElement closeBtn = wait.until(ExpectedConditions.elementToBeClickable(closeMenuButton));
        closeBtn.click();
    }

    public void clickAllItems() {
        WebElement link = wait.until(ExpectedConditions.elementToBeClickable(allItemsLink));
        link.click();
    }

    public void clickAbout() {
        WebElement link = wait.until(ExpectedConditions.elementToBeClickable(aboutLink));
        link.click();
    }

    public void clickLogout() {
        WebElement link = wait.until(ExpectedConditions.elementToBeClickable(logoutLink));
        link.click();
    }

    public void clickResetAppState() {
        WebElement link = wait.until(ExpectedConditions.elementToBeClickable(resetAppStateLink));
        link.click();
    }
}