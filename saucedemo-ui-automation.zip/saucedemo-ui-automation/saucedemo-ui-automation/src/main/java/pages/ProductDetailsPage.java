package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * Page Object representing the SauceDemo Product Details page.
 * Represents ONLY the single-product detail screen reached by clicking
 * a product name or product image on the Inventory page.
 */
public class ProductDetailsPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By productName = By.className("inventory_details_name");
    private final By productDescription = By.className("inventory_details_desc");
    private final By productPrice = By.className("inventory_details_price");
    private final By productImage = By.className("inventory_details_img");
    private final By addToCartButton = By.cssSelector("button.btn_inventory");
    private final By backToProductsButton = By.id("back-to-products");

    public ProductDetailsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public String getProductName() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(productName)).getText();
    }

    public String getProductDescription() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(productDescription)).getText();
    }

    public String getProductPrice() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(productPrice)).getText();
    }

    public boolean isProductImageDisplayed() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(productImage)).isDisplayed();
    }

    public boolean isAddToCartButtonDisplayed() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(addToCartButton)).isDisplayed();
    }

    public boolean isBackToProductsButtonDisplayed() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(backToProductsButton)).isDisplayed();
    }

    public ProductsPage clickBackToProducts() {
        WebElement backBtn = wait.until(ExpectedConditions.elementToBeClickable(backToProductsButton));
        backBtn.click();
        return new ProductsPage(driver);
    }
}