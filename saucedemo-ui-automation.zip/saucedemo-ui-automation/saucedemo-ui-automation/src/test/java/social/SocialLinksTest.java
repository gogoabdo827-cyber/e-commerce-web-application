package social;

import base.BaseTest;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.ProductsPage;

import java.time.Duration;

/**
 * Test class covering the SauceDemo Inventory page footer social links.
 * TC019.1: X (Twitter)
 * TC019.2: Facebook
 * TC019.3: LinkedIn
 *
 * Each social link opens in a new browser tab. Every test verifies the
 * opened tab's URL, closes that tab, and returns focus to the original
 * SauceDemo window so the driver is left in a clean state.
 */
public class SocialLinksTest extends BaseTest {

    private static final String VALID_USERNAME = "standard_user";
    private static final String VALID_PASSWORD = "secret_sauce";

    private static final String TWITTER_URL_FRAGMENT = "saucelabs";
    private static final String FACEBOOK_URL_FRAGMENT = "facebook.com/saucelabs";
    private static final String LINKEDIN_URL_FRAGMENT = "linkedin.com/company/sauce-labs";

    /**
     * Logs in with valid credentials and returns the resulting ProductsPage.
     */
    private ProductsPage loginAsStandardUser() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(VALID_USERNAME, VALID_PASSWORD);
        return new ProductsPage(driver);
    }

    /**
     * Shared verification flow for a footer social link:
     * 1. Records the current (SauceDemo) window handle.
     * 2. Performs the click action that opens a new tab.
     * 3. Waits for the new tab to appear and switches to it.
     * 4. Asserts the new tab's URL contains the expected fragment.
     * 5. Closes the new tab and switches back to the original window.
     *
     * @param clickAction        the FooterComponent click method to invoke (e.g. footer()::clickTwitter)
     * @param expectedUrlFragment substring expected in the opened tab's URL
     */
    private void verifySocialLink(Runnable clickAction, String expectedUrlFragment) {
        String originalWindow = driver.getWindowHandle();
        int originalWindowCount = driver.getWindowHandles().size();

        clickAction.run();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(d -> d.getWindowHandles().size() > originalWindowCount);

        String newWindow = driver.getWindowHandles().stream()
                .filter(handle -> !handle.equals(originalWindow))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("New social media tab did not open"));

        driver.switchTo().window(newWindow);
        wait.until(ExpectedConditions.urlContains(expectedUrlFragment));

        Assert.assertTrue(
                driver.getCurrentUrl().contains(expectedUrlFragment),
                "Expected the opened tab URL to contain: " + expectedUrlFragment
                        + " but was: " + driver.getCurrentUrl()
        );

        driver.close();
        driver.switchTo().window(originalWindow);
    }

    /**
     * TC019.1 - Verify X (Twitter)
     */
    @Test(priority = 19, description = "TC019.1 - Verify the X (Twitter) footer link opens the official Sauce Labs page")
    public void testTwitterLink() {
        ProductsPage productsPage = loginAsStandardUser();
        verifySocialLink(productsPage.footer()::clickTwitter, TWITTER_URL_FRAGMENT);
    }

    /**
     * TC019.2 - Verify Facebook
     */
    @Test(priority = 19, description = "TC019.2 - Verify the Facebook footer link opens the official Sauce Labs page")
    public void testFacebookLink() {
        ProductsPage productsPage = loginAsStandardUser();
        verifySocialLink(productsPage.footer()::clickFacebook, FACEBOOK_URL_FRAGMENT);
    }

    /**
     * TC019.3 - Verify LinkedIn
     */
    @Test(priority = 19, description = "TC019.3 - Verify the LinkedIn footer link opens the official Sauce Labs page")
    public void testLinkedInLink() {
        ProductsPage productsPage = loginAsStandardUser();
        verifySocialLink(productsPage.footer()::clickLinkedIn, LINKEDIN_URL_FRAGMENT);
    }
}
