package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Page Object representing Checkout Step Two (order overview) page.
 */
public class CheckoutStepTwoPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private final By cartItems = By.className("cart_item");
    private final By cartItemNames = By.className("inventory_item_name");
    private final By summarySubtotal = By.className("summary_subtotal_label");
    private final By summaryTax = By.className("summary_tax_label");
    private final By summaryTotal = By.className("summary_total_label");
    private final By finishButton = By.id("finish");
    private final By cancelButton = By.id("cancel");

    public CheckoutStepTwoPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public List<String> getOrderedItemNames() {
        List<WebElement> items = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(cartItems));
        return items.stream()
                .map(item -> item.findElement(cartItemNames).getText())
                .collect(Collectors.toList());
    }

    public String getSubtotal() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(summarySubtotal)).getText();
    }

    public String getTax() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(summaryTax)).getText();
    }

    public String getTotal() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(summaryTotal)).getText();
    }

    public CheckoutCompletePage clickFinish() {
        wait.until(ExpectedConditions.elementToBeClickable(finishButton)).click();
        return new CheckoutCompletePage(driver);
    }

    public ProductsPage clickCancel() {
        wait.until(ExpectedConditions.elementToBeClickable(cancelButton)).click();
        return new ProductsPage(driver);
    }
}